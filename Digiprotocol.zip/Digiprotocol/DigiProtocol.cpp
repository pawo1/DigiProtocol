/*******************************************************************************
 *  DigiProtocol is Library designed for Communication with DigiSpark over USB.
 *  It’s based on DigiUSB library but adds protocol-frame.
 *  Copyright (C) 2021 Pawo (pandretix.pl)
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *********************************************************************************/


#include "Arduino.h"
#include "DigiProtocol.h"

DigiProtocolClass::DigiProtocolClass() {
    _dataAvailable = 0;
    _crc = 0;
    _protocolProcess = false;
    _clear = 0;
}

void DigiProtocolClass::_sendID() {
    char ID[11];
    uint16_t crc = 0;
    bool zeros = true, fulls= true;

    for(int x=0; x<10; x++) {
        ID[x] = EEPROM.read(E2END+x);
        if(ID[x] != 0) zeros = false;
        if(ID[x] != 255) fulls = false;
        crc = _crc16_update(crc, ID[x]);
    }
    crc = _crc16_update(crc, EEPROM.read(E2END+10));
    crc = _crc16_update(crc, EEPROM.read(E2END+11));

    if(zeros || fulls) {
        sendRequest(DP_NEW_DEVICE);
    } else if(crc != 0) {
        _selfRepairID();
    } else {
        sendRequest(DP_ID_TRANSMISSION);
        ID[10] = '\0';
        sendMessage(ID);
    }
}

void DigiProtocolClass::_selfRepairID() {
    char ID[11];
    uint16_t crc = 0;

    for(int x=0; x<10; x++) {
        ID[x] = EEPROM.read(E2END+x+13);
        EEPROM.update(E2END+x, ID[x]);
        crc = _crc16_update(crc, ID[x]);
    }
    crc = _crc16_update(crc, EEPROM.read(E2END+23));
    crc = _crc16_update(crc, EEPROM.read(E2END+24));

    if(crc != 0) sendRequest(DP_CORRUPTED_ID);
    else {
        sendRequest(DP_BACKUP_TRANSMISSION);
        ID[10] = '\0';
        sendMessage(ID);
    }
}

void DigiProtocolClass::_burnID() {
    //sendMessage("Burning ID \n");
    char ID[11];
    DigiUSB.delay(2000);
    //DigiUSB.read(); DigiUSB.read();
    if(DigiUSB.read() != DP_START_OF_TRANSMISSION) sendRequest(DP_WRONG_REQUEST);
    if(DigiUSB.read() != 10 || DigiUSB.available() < 12) sendRequest(DP_WRONG_ID_FORMAT);
    else {
    uint16_t crc = 0;
    for(int x=0; x<10; x++) {
        ID[x] = DigiUSB.read();
        crc = _crc16_update(crc, ID[x]);
    }
    crc =  _crc16_update(crc, DigiUSB.read()); // 1st byte of CRC remaind
    crc =  _crc16_update(crc, DigiUSB.read()); // 2nd byte of CRC remaind

    if(crc != 0) { sendRequest(DP_REPEAT_MESSAGE); return; }

    crc = 0;

    for(int x=0; x<10; x++) {
        crc = _crc16_update(crc, ID[x]);
        EEPROM.update(E2END+x, ID[x]);
        EEPROM.update(E2END+x+13, ID[x]);
    }

    EEPROM.update(E2END+12, 45);

    EEPROM.update(E2END+10, (byte)(crc & 0xFF));
    EEPROM.update(E2END+11, (byte)(crc >> 8));
    EEPROM.update(E2END+23, (byte)(crc & 0xFF));
    EEPROM.update(E2END+24, (byte)(crc >> 8));

    _sendID();
    }
}


int DigiProtocolClass::available() {
    getRequest();
    if(DigiUSB.available() >= _dataAvailable+2)
      return _dataAvailable;
    return 0;
}

void DigiProtocolClass::getRequest() {
    uint8_t byte;

    if(DigiUSB.available() && _protocolProcess == true) {
        byte = DigiUSB.read();
        if(byte != -1) {
            _protocolProcess = false;
            _dataAvailable = byte;
        }
    } else if(DigiUSB.available() && _dataAvailable == 0) {

        byte = DigiUSB.read();
        switch(byte) {
        case DP_START_OF_TRANSMISSION:
            _protocolProcess = true;
            _crc = 0;
            break;
        case DP_SEND_ID:
            _sendID();
            break;
        case DP_SEND_STATUS:
            sendRequest(DP_STATUS_ALIVE);
            break;
        case DP_REPEAT_MESSAGE:
            _clear = DP_REPEAT_MESSAGE;
            break;
        case DP_BURN_ID:
            _burnID();
            break;
        default:
            _clear = DP_ERROR_WRONG_PROTOCOL;
            getRequest();
            break;
        }
    }


    usbPoll();

}

int DigiProtocolClass::read() {
    int buf = 0;

    if(_dataAvailable != 0 && DigiUSB.available() != 0) {
        buf = DigiUSB.read();
        _crc = _crc16_update(_crc, buf);
        _dataAvailable = _dataAvailable - 1;

        if(_dataAvailable == 0) {
            _crc =  _crc16_update(_crc, DigiUSB.read()); // 1st byte of CRC remaind
            _crc =  _crc16_update(_crc, DigiUSB.read()); // 2nd byte of CRC remaind
            if(_crc != 0) _clear = DP_ERROR_CORRUPTED_DATA;

        }

        return buf;
    }

    return -1;
}


void DigiProtocolClass::sendRequest(uint8_t request) {
    DigiUSB.write(request);
}

void DigiProtocolClass::sendMessage(char * message) {
uint16_t crc = 0;
DigiUSB.write(DP_START_OF_TRANSMISSION);
DigiUSB.write(strlen(message));
for(int x=0; x<strlen(message); x++) {
    crc = _crc16_update(crc, message[x]);
    DigiUSB.write(message[x]);
}
DigiUSB.write((byte)(crc & 0xFF));
DigiUSB.write((byte)(crc >> 8));


}

void DigiProtocolClass::clear() {
    while(DigiUSB.available())
      DigiUSB.read();
    _dataAvailable = 0;
}

void DigiProtocolClass::begin() {
    DigiUSB.begin();
}

void DigiProtocolClass::delay(long ms) {
    unsigned long last = millis();
    while (ms > 0) {
        unsigned long now = millis();
        ms -= now - last;
        last = now;
        getRequest();
    }
}

void DigiProtocolClass::refresh() {
    getRequest();
}

int DigiProtocolClass::error() {
    int temp = _clear;
    _clear = 0;
    return temp;
}

DigiProtocolClass DigiProtocol = DigiProtocolClass();
