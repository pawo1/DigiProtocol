/*******************************************************************************
 *  DigiProtocol is Library designed for Communication with DigiSpark over USB.
 *  It’s based on DigiUSB library but adds protocol-frame.
 *  Copyright (C) 2021 Pawo (pandretix.pl)
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *********************************************************************************/


#ifndef DIGIPROTOCOL_AVR_H
#define DIGIPROTOCOL_AVR_H

#include "Arduino.h"
#include <DigiUSB.h>
#include <util/crc16.h>

#if defined (__AVR_ATtiny85__)
#  include <avr/iotn85.h>
#else
#  if !defined(__COMPILING_AVR_LIBC__)
#    warning "device type not defined"
#  endif
#endif

#define E2END 0x1E6
#include "EEPROM/EEPROM.h"

// request definitions
#define DP_START_OF_TRANSMISSION 0xAA

#define DP_SEND_ID 0xBB
#define DP_SEND_STATUS 0xAF
#define DP_STATUS_ALIVE 0xFA
#define DP_REPEAT_MESSAGE 0xCC
#define DP_BURN_ID 0xDD
#define DP_WRONG_REQUEST 0xEE
#define DP_WRONG_ID_FORMAT 0xEA
#define DP_ID_TRANSMISSION 0xDA
#define DP_BACKUP_TRANSMISSION 0xDB
#define DP_CORRUPTED_ID 0xDC
#define DP_NEW_DEVICE 0xDE

// device VID/PID
#define VID 0x16c0
#define PID 0x05df
// error list
#define DP_NO_ERROR 0
#define DP_NO_DATA 0


#define DP_ACCESS_ERROR -1

#define DP_ERROR_DEVICE_DISCONNECTED -2
#define DP_ERROR_NO_DEVICE -3
#define DP_ERROR_WRONG_PROTOCOL -4
#define DP_ERROR_TIMEOUT -5
#define DP_ERROR_CORRUPTED_DATA -6
#define DP_ERROR_WRONG_SIZE -7
#define DP_ERROR_WRONG_ID_LENGTH -8


class DigiProtocolClass {
private:
    int _dataAvailable;
    uint16_t _crc;
    bool _protocolProcess;
    int _clear;

    void _sendID();
    void _selfRepairID();
    void _burnID();

public:
    DigiProtocolClass();

    int available();
    void getRequest();

    int read();


    void sendRequest(uint8_t request);
    void sendMessage(char * message);
    void clear();
    void begin();
    void delay(long ms);
    void refresh();
    int error();

};

extern DigiProtocolClass DigiProtocol;

#endif // DIGIPROTOCOL_AVR_H
